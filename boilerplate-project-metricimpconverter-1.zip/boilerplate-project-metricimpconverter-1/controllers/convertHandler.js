/*
*
*
* Lógica del convertHandler
*
*
*/

function ConvertHandler() {

  // 1. Unidades válidas y sus nombres completos (singular/plural)
  this.validUnits = ['gal', 'l', 'mi', 'km', 'lbs', 'kg'];
  this.unitStrings = {
    'gal': { singular: 'gallon', plural: 'gallons' },
    'l':   { singular: 'liter', plural: 'liters' },
    'mi':  { singular: 'mile', plural: 'miles' },
    'km':  { singular: 'kilometer', plural: 'kilometers' },
    'lbs': { singular: 'pound', plural: 'pounds' },
    'kg':  { singular: 'kilogram', plural: 'kilograms' }
  };

  // 2. Factores de conversión
  // Definimos ambos lados para simplificar la función this.convert
  this.conversionFactors = {
    'gal': 3.78541, // galón a litro
    'l': 1 / 3.78541, // litro a galón
    'mi': 1.60934, // milla a kilómetro
    'km': 1 / 1.60934, // kilómetro a milla
    'lbs': 0.453592, // libra a kilogramo
    'kg': 1 / 0.453592 // kilogramo a libra
  };


  // --- 1. PARSEAR NÚMERO ---
  this.getNum = function(input) {
    let result;

    // Encuentra el índice del primer carácter alfabético para separar el número de la unidad.
    const unitIndex = input.search(/[a-zA-Z]/);

    let numString;
    if (unitIndex === -1) {
      // Si no hay unidad (solo número), toma toda la entrada como número
      numString = input;
    } else if (unitIndex === 0) {
      // Si la unidad está al principio (no hay número explícito)
      numString = ''; 
    } else {
      // El número es la subcadena hasta el índice de la unidad
      numString = input.substring(0, unitIndex);
    }

    // Valor predeterminado a 1 si no se proporciona un número
    if (numString === '') {
      return 1;
    }

    numString = numString.replace(/ /g, '');

    // Verificar si es una doble fracción (ej: 3/2/3)
    if ((numString.match(/\//g) || []).length > 1) {
      return 'invalid number'; 
    }

    // Manejar fracciones
    if (numString.includes('/')) {
      const parts = numString.split('/');
      const numerator = parseFloat(parts[0]);
      const denominator = parseFloat(parts[1]);

      if (isNaN(numerator) || isNaN(denominator) || denominator === 0) {
        return 'invalid number'; 
      }

      result = numerator / denominator;
    } else {
      // Manejar enteros o decimales
      result = parseFloat(numString);

      if (isNaN(result)) {
        return 'invalid number'; 
      }
    }

    return result;
  };

  // --- 2. PARSEAR UNIDAD ---
  this.getUnit = function(input) {

    // Encuentra el índice del primer carácter alfabético
    const unitIndex = input.search(/[a-zA-Z]/);

    // Si no se encuentra ninguna letra
    if (unitIndex === -1) {
      return 'invalid unit'; 
    }

    let unitString = input.substring(unitIndex);

    // Normalizar la unidad: convertir a minúsculas
    let normalizedUnit = unitString.toLowerCase();

    // Validar si la unidad está en las unidades válidas
    if (!this.validUnits.includes(normalizedUnit)) {
      return 'invalid unit';
    }

    // Regla especial para Litro: debe devolverse como 'L' mayúscula
    if (normalizedUnit === 'l') {
      return 'L';
    } else {
      return normalizedUnit;
    }
  };

  // --- 3. OBTENER UNIDAD DE RETORNO ---
  this.getReturnUnit = function(initUnit) {
    let unitKey = initUnit.toLowerCase();

    switch (unitKey) {
      case 'gal': return 'L';
      case 'l': return 'gal';
      case 'mi': return 'km';
      case 'km': return 'mi';
      case 'lbs': return 'kg';
      case 'kg': return 'lbs';
      default: return 'invalid unit'; 
    }
  };

  // --- 4. OBTENER STRING DE UNIDAD (NOMBRE COMPLETO) ---
  this.spellOutUnit = function(unit) {
    let unitKey = unit.toLowerCase();

    if (this.unitStrings[unitKey]) {
      // Retorna el nombre en singular.
      return this.unitStrings[unitKey].singular; 
    }

    return 'invalid unit name';
  };

  // --- 5. REALIZAR CONVERSIÓN ---
  this.convert = function(initNum, initUnit) {

    const unitKey = initUnit.toLowerCase();
    const factor = this.conversionFactors[unitKey];

    if (!factor) {
      return 'conversion error'; 
    }

    let returnNum = initNum * factor;

    // Redondear a 5 decimales
    return parseFloat(returnNum.toFixed(5));
  };

  // --- 6. CONSTRUIR EL STRING DE SALIDA ---
  this.getString = function(initNum, initUnit, returnNum, returnUnit) {
    const initUnitKey = initUnit.toLowerCase();
    const returnUnitKey = returnUnit.toLowerCase();

    const initUnitString = this.unitStrings[initUnitKey];
    const returnUnitString = this.unitStrings[returnUnitKey];

    // Determinar singular o plural basado en el número
    const spelledInitUnit = (initNum === 1) ? initUnitString.singular : initUnitString.plural;
    const spelledReturnUnit = (returnNum === 1) ? returnUnitString.singular : returnUnitString.plural;

    return `${initNum} ${spelledInitUnit} converts to ${returnNum} ${spelledReturnUnit}`;
  };

}

module.exports = ConvertHandler;