/*
*
*
* Pruebas Funcionales para la API /api/convert
*
*
*/

const chaiHttp = require('chai-http');
const chai = require('chai');
let assert = chai.assert;
const server = require('../server'); // Asegúrate de que este path apunta a tu archivo server.js

chai.use(chaiHttp);

suite('Functional Tests', function() {

  // 1. Convierte una entrada válida (ej: 10L): GET solicitud a /api/convert.
  test('Convert a valid input such as 10L: GET request to /api/convert.', function(done) {
    chai.request(server)
      .get('/api/convert')
      .query({ input: '10L' })
      .end(function(err, res) {
        assert.equal(res.status, 200);
        assert.equal(res.body.initNum, 10);
        assert.equal(res.body.initUnit, 'L');
        // 10 L a galones: 2.6417202...
        assert.approximately(res.body.returnNum, 2.64172, 0.00001); 
        assert.equal(res.body.returnUnit, 'gal');
        assert.equal(res.body.string, '10 liters converts to 2.64172 gallons');
        done();
      });
  });

  // 2. Convierte una unidad no válida (ej: 32g): GET solicitud a /api/convert.
  test('Convert an invalid unit such as 32g: GET request to /api/convert.', function(done) {
    chai.request(server)
      .get('/api/convert')
      .query({ input: '32g' })
      .end(function(err, res) {
        assert.equal(res.status, 200);
        // Debe devolver el mensaje de error de unidad inválida.
        assert.equal(res.text, 'invalid unit'); 
        done();
      });
  });

  // 3. Convierte un número no válido (ej: 3/7.2/4kg): GET solicitud a /api/convert.
  test('Convert an invalid number such as 3/7.2/4kg: GET request to /api/convert.', function(done) {
    chai.request(server)
      .get('/api/convert')
      .query({ input: '3/7.2/4kg' })
      .end(function(err, res) {
        assert.equal(res.status, 200);
        // Debe devolver el mensaje de error de número inválido (doble fracción).
        assert.equal(res.text, 'invalid number'); 
        done();
      });
  });

  // 4. Convierte un número Y una unidad no válidos (ej: 3/7.2/4kilomegagram): GET solicitud a /api/convert.
  test('Convert an invalid number and unit such as 3/7.2/4kilomegagram: GET request to /api/convert.', function(done) {
    chai.request(server)
      .get('/api/convert')
      .query({ input: '3/7.2/4kilomegagram' })
      .end(function(err, res) {
        assert.equal(res.status, 200);
        // Debe devolver el mensaje combinado.
        assert.equal(res.text, 'invalid number and unit'); 
        done();
      });
  });

  // 5. Convertir sin número (ej: kg): GET solicitud a /api/convert.
  test('Convert with no number such as kg: GET request to /api/convert.', function(done) {
    chai.request(server)
      .get('/api/convert')
      .query({ input: 'kg' })
      .end(function(err, res) {
        assert.equal(res.status, 200);
        // Debe usar el valor predeterminado de 1
        assert.equal(res.body.initNum, 1);
        assert.equal(res.body.initUnit, 'kg');
        // 1 kg a lbs: 2.204622...
        assert.approximately(res.body.returnNum, 2.20462, 0.00001); 
        assert.equal(res.body.returnUnit, 'lbs');
        assert.equal(res.body.string, '1 kilogram converts to 2.20462 pounds');
        done();
      });
  });

});