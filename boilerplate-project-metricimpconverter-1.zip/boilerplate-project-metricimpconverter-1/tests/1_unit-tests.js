/*
*
*
* Pruebas Unitarias para convertHandler.js
*
*
*/

const chai = require('chai');
let assert = chai.assert;
const ConvertHandler = require('../controllers/convertHandler.js');

let convertHandler = new ConvertHandler();

suite('Unit Tests', function(){

  // --- PRUEBAS PARA getNum(input) ---
  suite('Function convertHandler.getNum(input)', function() {

    // 1. Debe leer correctamente una entrada de número entero.
    test('Should correctly read a whole number input.', function(done) {
      let input = '32L';
      assert.equal(convertHandler.getNum(input), 32, 'debe leer correctamente el número entero 32');
      done();
    });

    // 2. Debe leer correctamente una entrada de número decimal.
    test('Should correctly read a decimal number input.', function(done) {
      let input = '32.5mi';
      assert.equal(convertHandler.getNum(input), 32.5, 'debe leer correctamente el número decimal 32.5');
      done();
    });

    // 3. Debe leer correctamente una entrada fraccionaria.
    test('Should correctly read a fractional input.', function(done) {
      let input = '1/2kg';
      assert.equal(convertHandler.getNum(input), 0.5, 'debe leer correctamente la fracción 1/2 (0.5)');
      done();
    });

    // 4. Debe leer correctamente una entrada fraccionaria con un decimal.
    test('Should correctly read a fractional input with a decimal.', function(done) {
      let input = '2.5/5lbs';
      assert.equal(convertHandler.getNum(input), 0.5, 'debe leer correctamente la fracción 2.5/5 (0.5)');
      done();
    });

    // 5. Debe devolver correctamente un error en una fracción doble (ej: 3/2/3).
    test('Should correctly return an error on a double-fraction (i.e. 3/2/3).', function(done) {
      let input = '3/2/3gal';
      assert.equal(convertHandler.getNum(input), 'invalid number', 'debe devolver error para doble fracción');
      done();
    });

    // 6. Debe establecerse correctamente de manera predeterminada en 1 cuando no se proporciona ninguna entrada numérica.
    test('Should correctly default to a numerical input of 1 when no numerical input is provided.', function(done) {
      let input = 'km';
      assert.equal(convertHandler.getNum(input), 1, 'debe establecer el valor predeterminado a 1');
      done();
    });

  });

  // --- PRUEBAS PARA getUnit(input) ---
  suite('Function convertHandler.getUnit(input)', function() {

    // 7. Debe leer correctamente cada unidad de entrada válida.
    test('Should correctly read each valid input unit.', function(done) {
      // Unidades válidas, incluyendo mayúsculas y minúsculas.
      let input = ['gal','l','mi','km','lbs','kg','GAL','L','MI','KM','LBS','KG'];
      // El resultado esperado debe ser minúscula, excepto 'L' (litros).
      let expected = ['gal','L','mi','km','lbs','kg','gal','L','mi','km','lbs','kg'];

      input.forEach(function(ele, i) {
        assert.equal(convertHandler.getUnit(ele), expected[i], `debe leer correctamente la unidad ${ele}`);
      });
      done();
    });

    // 8. Debería devolver correctamente un error para una unidad de entrada no válida.
    test('Should correctly return an error for an invalid input unit.', function(done) {
      let input = '32g'; // 'g' no es una unidad válida
      assert.equal(convertHandler.getUnit(input), 'invalid unit', 'debe devolver error para unidad no válida (g)');
      done();
    });

  });

  // --- PRUEBAS PARA getReturnUnit(initUnit) ---
  suite('Function convertHandler.getReturnUnit(initUnit)', function() {

    // 9. Debe devolver la unidad de devolución correcta para cada unidad de entrada válida.
    test('Should return the correct return unit for each valid input unit.', function(done) {
      let input = ['gal','L','mi','km','lbs','kg'];
      let expected = ['L','gal','km','mi','kg','lbs'];
      input.forEach(function(ele, i) {
        assert.equal(convertHandler.getReturnUnit(ele), expected[i], `debe devolver la unidad de retorno correcta para ${ele}`);
      });
      done();
    });

  });

  // --- PRUEBAS PARA spellOutUnit(unit) ---
  suite('Function convertHandler.spellOutUnit(unit)', function() {

    // 10. Debe devolver correctamente la unidad de cadena escrita para cada unidad de entrada válida.
    test('Should correctly return the spelled-out string unit for each valid input unit.', function(done) {
      let input = ['gal','L','mi','km','lbs','kg'];
      let expected = ['gallon','liter','mile','kilometer','pound','kilogram'];
      input.forEach(function(ele, i) {
        assert.equal(convertHandler.spellOutUnit(ele), expected[i], `debe deletrear la unidad ${ele} como ${expected[i]}`);
      });
      done();
    });

  });

  // --- PRUEBAS PARA convert(num, unit) ---
  suite('Function convertHandler.convert(num, unit)', function() {

    // Usamos assert.approximately para verificar la precisión flotante (5 decimales)

    // 11. Debe convertir correctamente gal a L.
    test('Should correctly convert gal to L.', function(done) {
      let input = [5, 'gal'];
      let expected = 18.92705; 
      assert.approximately(convertHandler.convert(input[0], input[1]), expected, 0.00001, '5 gal debe ser 18.92705 L');
      done();
    });

    // 12. Debe convertir correctamente L a gal.
    test('Should correctly convert L to gal.', function(done) {
      let input = [18.92705, 'L'];
      let expected = 5.00000; 
      assert.approximately(convertHandler.convert(input[0], input[1]), expected, 0.00001, '18.92705 L debe ser 5 gal');
      done();
    });

    // 13. Debe convertir correctamente mi a km.
    test('Should correctly convert mi to km.', function(done) {
      let input = [5, 'mi'];
      let expected = 8.04670; 
      assert.approximately(convertHandler.convert(input[0], input[1]), expected, 0.00001, '5 mi debe ser 8.04670 km');
      done();
    });

    // 14. Debe convertir correctamente km a mi.
    test('Should correctly convert km to mi.', function(done) {
      let input = [8.0467, 'km'];
      let expected = 5.00000;
      assert.approximately(convertHandler.convert(input[0], input[1]), expected, 0.00001, '8.0467 km debe ser 5 mi');
      done();
    });

    // 15. Debe convertir correctamente lbs a kg.
    test('Should correctly convert lbs to kg.', function(done) {
      let input = [5, 'lbs'];
      let expected = 2.26796; 
      assert.approximately(convertHandler.convert(input[0], input[1]), expected, 0.00001, '5 lbs debe ser 2.26796 kg');
      done();
    });

    // 16. Debe convertir correctamente kg a lbs.
    test('Should correctly convert kg to lbs.', function(done) {
      let input = [2.26796, 'kg'];
      let expected = 5.00000;
      assert.approximately(convertHandler.convert(input[0], input[1]), expected, 0.00001, '2.26796 kg debe ser 5 lbs');
      done();
    });

  });

});