/*
*
*
* Rutas API
*
*
*/

'use strict';

const ConvertHandler = require('../controllers/convertHandler.js');

module.exports = function (app) {

  let convertHandler = new ConvertHandler();

  app.route('/api/convert')
    .get(function (req, res){
      let input = req.query.input;

      // 1. Parsear
      let initNum = convertHandler.getNum(input);
      let initUnit = convertHandler.getUnit(input);

      let returnNum, returnUnit, toString;

      const isInvalidNum = initNum === 'invalid number';
      const isInvalidUnit = initUnit === 'invalid unit';

      // 2. Manejo de errores (Orden: ambos, número, unidad)
      if (isInvalidNum && isInvalidUnit) {
        return res.send('invalid number and unit');
      }

      if (isInvalidNum) {
        return res.send('invalid number');
      }

      if (isInvalidUnit) {
        return res.send('invalid unit');
      }

      // 3. Conversión
      returnUnit = convertHandler.getReturnUnit(initUnit);
      returnNum = convertHandler.convert(initNum, initUnit);
      toString = convertHandler.getString(initNum, initUnit, returnNum, returnUnit);

      // 4. Respuesta JSON
      res.json({
        initNum: initNum,
        initUnit: initUnit,
        returnNum: returnNum,
        returnUnit: returnUnit,
        string: toString
      });
    });
};